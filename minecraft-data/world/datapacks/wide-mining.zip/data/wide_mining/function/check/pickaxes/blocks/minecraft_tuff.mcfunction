execute if score @s .wide_mining.minecraft_tuff matches 1.. run scoreboard players set @s .wide_mining.others.users 1
execute if score @s .wide_mining.minecraft_tuff matches 1.. run execute at @e[type=item,sort=nearest,limit=1,nbt={Age:0s}] run function wide_mining:mine/pickaxes
execute if score @s .wide_mining.minecraft_tuff matches 1.. run scoreboard players reset @s .wide_mining.minecraft_tuff