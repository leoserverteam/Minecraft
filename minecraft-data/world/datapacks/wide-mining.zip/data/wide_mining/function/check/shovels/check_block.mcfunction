function wide_mining:check/shovels/blocks/minecraft_dirt
function wide_mining:check/shovels/blocks/minecraft_grass_block
function wide_mining:check/shovels/blocks/minecraft_gravel
function wide_mining:check/shovels/blocks/minecraft_sand
function wide_mining:check/shovels/blocks/minecraft_clay
function wide_mining:check/shovels/blocks/minecraft_coarse_dirt
function wide_mining:check/shovels/blocks/minecraft_mud
function wide_mining:check/shovels/blocks/minecraft_mycelium
function wide_mining:check/shovels/blocks/minecraft_podzol
function wide_mining:check/shovels/blocks/minecraft_red_sand
function wide_mining:check/shovels/blocks/minecraft_snow_block
function wide_mining:check/shovels/blocks/minecraft_soul_sand
function wide_mining:check/shovels/blocks/minecraft_soul_soil
execute if score @s .wide_mining.others.users matches 1 run return run scoreboard players reset @s .wide_mining.others.users