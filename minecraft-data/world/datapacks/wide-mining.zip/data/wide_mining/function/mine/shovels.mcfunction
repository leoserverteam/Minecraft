execute if block ~-1 ~-1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~-1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~-1 ~-1 mine ~-1 ~-1 ~-1 mainhand
execute if block ~-1 ~-1 ~-1 #wide_mining:minables/shovels run setblock ~-1 ~-1 ~-1 air destroy
execute if block ~-1 ~-1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~-1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~-1 ~0 mine ~-1 ~-1 ~0 mainhand
execute if block ~-1 ~-1 ~0 #wide_mining:minables/shovels run setblock ~-1 ~-1 ~0 air destroy
execute if block ~-1 ~-1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~-1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~-1 ~1 mine ~-1 ~-1 ~1 mainhand
execute if block ~-1 ~-1 ~1 #wide_mining:minables/shovels run setblock ~-1 ~-1 ~1 air destroy
execute if block ~-1 ~0 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~0 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~0 ~-1 mine ~-1 ~0 ~-1 mainhand
execute if block ~-1 ~0 ~-1 #wide_mining:minables/shovels run setblock ~-1 ~0 ~-1 air destroy
execute if block ~-1 ~0 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~0 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~0 ~0 mine ~-1 ~0 ~0 mainhand
execute if block ~-1 ~0 ~0 #wide_mining:minables/shovels run setblock ~-1 ~0 ~0 air destroy
execute if block ~-1 ~0 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~0 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~0 ~1 mine ~-1 ~0 ~1 mainhand
execute if block ~-1 ~0 ~1 #wide_mining:minables/shovels run setblock ~-1 ~0 ~1 air destroy
execute if block ~-1 ~1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~1 ~-1 mine ~-1 ~1 ~-1 mainhand
execute if block ~-1 ~1 ~-1 #wide_mining:minables/shovels run setblock ~-1 ~1 ~-1 air destroy
execute if block ~-1 ~1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~1 ~0 mine ~-1 ~1 ~0 mainhand
execute if block ~-1 ~1 ~0 #wide_mining:minables/shovels run setblock ~-1 ~1 ~0 air destroy
execute if block ~-1 ~1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~-1 ~1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~-1 ~1 ~1 mine ~-1 ~1 ~1 mainhand
execute if block ~-1 ~1 ~1 #wide_mining:minables/shovels run setblock ~-1 ~1 ~1 air destroy
execute if block ~0 ~-1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~-1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~-1 ~-1 mine ~0 ~-1 ~-1 mainhand
execute if block ~0 ~-1 ~-1 #wide_mining:minables/shovels run setblock ~0 ~-1 ~-1 air destroy
execute if block ~0 ~-1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~-1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~-1 ~0 mine ~0 ~-1 ~0 mainhand
execute if block ~0 ~-1 ~0 #wide_mining:minables/shovels run setblock ~0 ~-1 ~0 air destroy
execute if block ~0 ~-1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~-1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~-1 ~1 mine ~0 ~-1 ~1 mainhand
execute if block ~0 ~-1 ~1 #wide_mining:minables/shovels run setblock ~0 ~-1 ~1 air destroy
execute if block ~0 ~0 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~0 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~0 ~-1 mine ~0 ~0 ~-1 mainhand
execute if block ~0 ~0 ~-1 #wide_mining:minables/shovels run setblock ~0 ~0 ~-1 air destroy
execute if block ~0 ~0 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~0 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~0 ~0 mine ~0 ~0 ~0 mainhand
execute if block ~0 ~0 ~0 #wide_mining:minables/shovels run setblock ~0 ~0 ~0 air destroy
execute if block ~0 ~0 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~0 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~0 ~1 mine ~0 ~0 ~1 mainhand
execute if block ~0 ~0 ~1 #wide_mining:minables/shovels run setblock ~0 ~0 ~1 air destroy
execute if block ~0 ~1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~1 ~-1 mine ~0 ~1 ~-1 mainhand
execute if block ~0 ~1 ~-1 #wide_mining:minables/shovels run setblock ~0 ~1 ~-1 air destroy
execute if block ~0 ~1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~1 ~0 mine ~0 ~1 ~0 mainhand
execute if block ~0 ~1 ~0 #wide_mining:minables/shovels run setblock ~0 ~1 ~0 air destroy
execute if block ~0 ~1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~0 ~1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~0 ~1 ~1 mine ~0 ~1 ~1 mainhand
execute if block ~0 ~1 ~1 #wide_mining:minables/shovels run setblock ~0 ~1 ~1 air destroy
execute if block ~1 ~-1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~-1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~-1 ~-1 mine ~1 ~-1 ~-1 mainhand
execute if block ~1 ~-1 ~-1 #wide_mining:minables/shovels run setblock ~1 ~-1 ~-1 air destroy
execute if block ~1 ~-1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~-1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~-1 ~0 mine ~1 ~-1 ~0 mainhand
execute if block ~1 ~-1 ~0 #wide_mining:minables/shovels run setblock ~1 ~-1 ~0 air destroy
execute if block ~1 ~-1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~-1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~-1 ~1 mine ~1 ~-1 ~1 mainhand
execute if block ~1 ~-1 ~1 #wide_mining:minables/shovels run setblock ~1 ~-1 ~1 air destroy
execute if block ~1 ~0 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~0 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~0 ~-1 mine ~1 ~0 ~-1 mainhand
execute if block ~1 ~0 ~-1 #wide_mining:minables/shovels run setblock ~1 ~0 ~-1 air destroy
execute if block ~1 ~0 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~0 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~0 ~0 mine ~1 ~0 ~0 mainhand
execute if block ~1 ~0 ~0 #wide_mining:minables/shovels run setblock ~1 ~0 ~0 air destroy
execute if block ~1 ~0 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~0 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~0 ~1 mine ~1 ~0 ~1 mainhand
execute if block ~1 ~0 ~1 #wide_mining:minables/shovels run setblock ~1 ~0 ~1 air destroy
execute if block ~1 ~1 ~-1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~1 ~-1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~1 ~-1 mine ~1 ~1 ~-1 mainhand
execute if block ~1 ~1 ~-1 #wide_mining:minables/shovels run setblock ~1 ~1 ~-1 air destroy
execute if block ~1 ~1 ~0 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~1 ~0 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~1 ~0 mine ~1 ~1 ~0 mainhand
execute if block ~1 ~1 ~0 #wide_mining:minables/shovels run setblock ~1 ~1 ~0 air destroy
execute if block ~1 ~1 ~1 #wide_mining:minables/shovels run gamerule minecraft:block_drops false
execute if block ~1 ~1 ~1 #wide_mining:minables/shovels run execute as @p[scores={.wide_mining.others.users=1}] run loot spawn ~1 ~1 ~1 mine ~1 ~1 ~1 mainhand
execute if block ~1 ~1 ~1 #wide_mining:minables/shovels run setblock ~1 ~1 ~1 air destroy
gamerule block_drops true