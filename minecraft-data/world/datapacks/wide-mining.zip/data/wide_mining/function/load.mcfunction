scoreboard objectives add .wide_mining.diagnose dummy
scoreboard players set $ok .wide_mining.diagnose 0

function wide_mining:diagnose

function wide_mining:reset/pickaxes
function wide_mining:reset/shovels
function wide_mining:reset/others
function wide_mining:setup/pickaxes
function wide_mining:setup/shovels
function wide_mining:setup/others
gamerule block_drops true

execute if score $ok .wide_mining.diagnose matches 1 run tellraw @a [ {"text":"[Wide Mining] ","color":"#8000F0","bold":true}, {"text":"loaded successfully.","bold":false,"color":"#6fbf73"} ]
execute unless score $ok .wide_mining.diagnose matches 1 run tellraw @a [ {"text":"[Wide Mining] ","color":"#8000F0","bold":true}, {"text":"failed to load. Please restart the world.","bold":false,"color":"#e64545"} ]

scoreboard objectives remove .wide_mining.diagnose