function wide_mining:reset/pickaxes
function wide_mining:reset/shovels
function wide_mining:reset/others
tellraw @a [ {"text":"[Wide Mining]","color":"#8000F0","bold":true}, {"text":" has been uninstalled. You may now safely remove the pack in your datapacks folder.","color":"#F80E0A","bold":false} ]